# IN14_NIXIEClock

整个项目基于 @silentcedar 的项目制作 https://github.com/silentcedar/NixieTubeClock

<img src="https://github.com/zzx0226/IN14_NIXIEClock/blob/master/Picture/1.png" style="width: 50%; height: 50%"/>
<img src="https://github.com/zzx0226/IN14_NIXIEClock/blob/master/Picture/2.png" style="width: 50%; height: 50%"/>
<img src="https://github.com/zzx0226/IN14_NIXIEClock/blob/master/Picture/3.png" style="width: 50%; height: 50%"/>

在此基础上增加/改变了：

    ·GPS自动校;

    ·在辉光管下放置RGB改变辉光管的颜色；
	
    ·通过咪头对声音采样来开启辉光管与RGB来延长辉光管的寿命
    
    ·增加了一块128x64的OLED方便调试；
	
    ·通过两板堆叠来减小整个辉光钟的体积；

关于价格的说明：

    ·单根全新IN14辉光管在淘宝的均价在100RMB左右；


    ·两块板各打10块的价格的均价在200RMB左右；


    ·其余芯片在淘宝的配单商家都可以采购到，成本在200RMB以下；
	
PS:

    ·整个制作中需要示波器、万用表、直流稳压电源等专业仪器；

    ·没有电子专业背景或者各类制作经验的朋友深入此坑；

    ·如果喜欢的话请star一下呀~

如果遇到问题欢迎进行讨论~ 我的邮箱：zzx0226@hotmail.com

祝好~
